document.write(infoNavegador.nombre);
document.write("</p>");