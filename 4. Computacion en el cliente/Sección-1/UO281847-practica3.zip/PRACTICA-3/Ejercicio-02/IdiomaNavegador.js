document.write(infoNavegador.idioma);
document.write("</p>")