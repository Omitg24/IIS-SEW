document.write("<p>");
document.write(asignatura.titulacion);
document.write("</p>");