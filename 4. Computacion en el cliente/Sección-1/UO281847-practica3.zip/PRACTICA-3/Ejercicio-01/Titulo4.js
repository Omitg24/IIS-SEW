document.write("<p>");
document.write(asignatura.universidad);
document.write("</p>");