var asignatura = new Object();
asignatura.nombre = "Software y estándares en la Web";
asignatura.titulacion = "Grado en Ingeniería Informática del Software";
asignatura.centro = "Escuela de Ingeniería Informática";
asignatura.universidad = "Universidad de Oviedo";
asignatura.curso = "2022-2023";
asignatura.estudiante = "Omar Teixeira González";
asignatura.email = "uo281847@uniovi.es";