document.write("<p>");
document.write(asignatura.centro);
document.write("</p>");